# FUNÇÕES ATIVAS

✅ WEBSOCKET

✅ WEBSOCKET SECURITY

✅ PROXY DT

✅ V2RAY

✅ BOT TELEGRAM

✅ BADVPN X VÁRIAS PORTAS

✅ SOFTETHER VPN

## :heavy_exclamation_mark: OBRIGATÓRIO
* Instale em um sistema operacional baseado em Linux (Ubuntu ou Debian)
* SERVIDOR UBUNTU 18.04 x86_64 / SERVIDOR UBUNTU 20.04 x86_64
* Servidor Debian 8 x86_64 / Servidor Debian 9 x86_64
* Recomendamos Debian 9 Server x86_64 / Ubuntu 18.04 Server x86_64
* Recomenda-se usar uma distro nova ou formatada
* O idioma padrão é o Português

# SCRIPTPLUS
````bash
apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/fleetvpngit/SCRIPTPLUS/master/Plus && chmod 777 Plus && ./Plus
````

# ACESSAR USUÁRIO ROOT
````bash
wget https://raw.githubusercontent.com/fleetvpngit/SCRIPTPLUS/master/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
````